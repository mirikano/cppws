//
// utf8 class header
//

#pragma once

#ifndef _UTF8_H
#define _UTF8_H

#include <iostream>

class utf8 {
    unsigned char byte[6];
    //
    // utf8 内部で使う定数
    static constexpr char BytesMap[] = {
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,		// 00 - 0F
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,		// 10 - 1F
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,		// 20 - 2F
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,		// 30 - 3F
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,		// 40 - 4F
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,		// 50 - 5F
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,		// 60 - 6F
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,		// 70 - 7F
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,		// 80 - 8F
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,		// 90 - 9F
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,		// A0 - AF
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,		// B0 - BF
	2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,		// C0 - CF
	2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,		// D0 - DF
	3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,		// E0 - EF
	4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6,-1,-1		// F0 - EF
    };
    static const utf8 ASCII_BOT;
    static const utf8 ASCII_TOP;
    static const utf8 SYMBOL_BOT;
    static const utf8 SYMBOL_TOP;
    static const utf8 HIRAGANA_BOT;
    static const utf8 HIRAGANA_TOP;
    static const utf8 KATAKANA_BOT;
    static const utf8 KATAKANA_TOP;
    static const utf8 KANJI_BOT;
    static const utf8 KANJI_TOP;
    static const utf8 SYMBOL_KANJI_SP1;
    static const utf8 SYMBOL_KANJI_SP2;

  public:
    enum CharType { ASCII, SYMBOL, HIRAGANA, KATAKANA, KANJI, OTHER, NONE };

    // コンストラクタ
    utf8(unsigned char x0 = 0, unsigned char x1 = 0, unsigned char x2 = 0,
         unsigned char x3 = 0, unsigned char x4 = 0, unsigned char x5 = 0);
    utf8(const unsigned char *xp);
    utf8(const char *xp);
    utf8(const utf8 &);

    // メンバ関数
    inline bool is_null() const { return (byte[0] == 0); }
    int count_bytes() const;
    CharType get_chartype() const;
    std::string hex_dump() const;

    // 演算子 overload
    bool operator<(const utf8 &) const;
    bool operator<=(const utf8 &) const;
    bool operator>(const utf8 &) const;
    bool operator>=(const utf8 &) const;
    bool operator==(const utf8 &) const;

    // 外部アクセス指定
    friend std::istream &operator>>(std::istream &, utf8 &);
    friend std::ostream &operator<<(std::ostream &, const utf8 &);
    friend std::ostream &operator<<(std::ostream &, const utf8 *);

};

#endif // _UTF8_H
